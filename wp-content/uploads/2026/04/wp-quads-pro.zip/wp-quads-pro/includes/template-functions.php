<?php

/**
 * Template Functions
 *
 * @package     QUADS
 * @subpackage  Functions/Templates
 * @copyright   Copyright (c) 2015, René Hermenau
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       0.9.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) )
   exit;

add_filter('the_content', 'quads_pro_process_content', quads_get_load_priority());

/**
 *
 * @global arr $quads_options
 * @global type $adsArray
 * @param type $content
 * @return type
 */
function quads_pro_process_content( $content )
{
    global $quads_mode, $quads_options, $adsArray, $adsArrayCus, $visibleContentAds, $ad_count_widget, $visibleShortcodeAds;

    // Array of ad codes ids
    $adsArray = quads_get_active_ads();

    // Return is no ads are defined
    if ($adsArray === 0 && $quads_mode != 'new') {
        return $content;
    }
    $content = quads_parse_group_insert_ads( $content );
    $content = quads_parse_rotator_ads( $content );
    $content = quads_parse_sticky_scroll_ads( $content );
    return $content;

}
add_filter( 'quads_default_filter_position_data', 'quadspro_default_filter_position_data',10 ,1 );

function quadspro_default_filter_position_data($ads){

    if($ads['ad_type']== 'ad_blindness' ){
        $cusads = '<!--CusRot'.esc_html($ads['ad_id']).'-->';

        if(isset($ads['ad_blindness']))
        $ads['ad_blindness'] = unserialize($ads['ad_blindness']);

        $key = array_rand($ads['ad_blindness']);

        $ad_blindness = $ads['ad_blindness'][$key];
        $ads=array_merge($ads,$ad_blindness);

        if(isset($ads['ads_list']))
        $ads['ads_list'] = unserialize($ads['ads_list']);
        $ads['ad_id'] = $ads['ads_list'][0]['value'];
    }
    return $ads;
}

add_filter( 'quads_default_filter_position_data_ab_testing', 'quadspro_default_filter_position_data2',10 ,1 );
function quadspro_default_filter_position_data2($ads){    

    if($ads['ad_type']== 'ab_testing' ){
        $cusads = '<!--CusRot'.esc_html($ads['ad_id']).'-->';
        if(isset($ads['ab_testing']))
        $ads['ab_testing'] = unserialize($ads['ab_testing']);
        $key = array_rand($ads['ab_testing']);
       
        $ab_testing = $ads['ab_testing'][$key];

        $ads=array_merge($ads,$ab_testing);
        if( $ab_testing["position"] == 'beginning_of_post' ){
            add_filter('wp_quads_content_html_last_filter','wpquads_content_pos_b_modifier');
            if(!function_exists('wpquads_content_pos_b_modifier')){
                function wpquads_content_pos_b_modifier( $content_buffer ){
                    $content_buffer = preg_replace("/class=\"quads-location(.*?)\"/", "class=\"quads-location$1\" data-attr=\"beginning_of_post\" "  , $content_buffer);
                    return $content_buffer;
                }
            }
        }
        if( $ab_testing["position"] == 'end_of_post' ){
            add_filter('wp_quads_content_html_last_filter','wpquads_content_pos_e_modifier');
            if(!function_exists('wpquads_content_pos_e_modifier')){
                function wpquads_content_pos_e_modifier( $content_buffer ){
                    $content_buffer = preg_replace("/class=\"quads-location(.*?)\"/", "class=\"quads-location$1\" data-attr=\"end_of_post\" "  , $content_buffer);
                    return $content_buffer;
                }
            }            
        }
        if( $ab_testing["position"] == 'middle_of_post' ){
            add_filter('wp_quads_content_html_last_filter','wpquads_content_pos_mid_modifier');
            if(!function_exists('wpquads_content_pos_mid_modifier')){
                function wpquads_content_pos_mid_modifier( $content_buffer ){
                    $content_buffer = preg_replace("/class=\"quads-location(.*?)\"/", "class=\"quads-location$1\" data-attr=\"middle_of_post\" "  , $content_buffer);
                    return $content_buffer;
                }
            }            
        }
        if( $ab_testing["position"] == 'after_more_tag' ){
            add_filter('wp_quads_content_html_last_filter','wpquads_content_pos_amt_modifier');
            if(!function_exists('wpquads_content_pos_amt_modifier')){
                function wpquads_content_pos_amt_modifier( $content_buffer ){
                    $content_buffer = preg_replace("/class=\"quads-location(.*?)\"/", "class=\"quads-location$1\" data-attr=\"after_more_tag\" "  , $content_buffer);
                    return $content_buffer;
                }
            }            
        }

        if(isset($ads['ads_list']))
        $ads['ads_list'] = unserialize($ads['ads_list']);
        $ads['ad_id'] = $ads['ads_list'][0]['value'];

    }
        return apply_filters( 'quads_ads_data' , $ads);
}

add_action('wp_ajax_nopriv_quads_insert_ad_clicks_beginning_of_post',  'quads_insert_ad_clicks_beginning_of_post');      
add_action('wp_ajax_quads_insert_ad_clicks_beginning_of_post',  'quads_insert_ad_clicks_beginning_of_post');
function quads_insert_ad_clicks_beginning_of_post( ){
    global $wpdb;
    $stats = $wpdb->get_var($wpdb->prepare("SELECT * FROM `{$wpdb->prefix}quads_stats`" ));
    if($stats>0){
        $wpdb->query( "UPDATE `{$wpdb->prefix}quads_stats` SET `Beginning_of_post` = `Beginning_of_post` + 1 WHERE `id` = {$stats};" );
    }
}

add_action('wp_ajax_nopriv_quads_insert_ad_clicks_end_of_post',  'quads_insert_ad_clicks_end_of_post');      
add_action('wp_ajax_quads_insert_ad_clicks_end_of_post',  'quads_insert_ad_clicks_end_of_post');
function quads_insert_ad_clicks_end_of_post( ){
    global $wpdb;
    $stats = $wpdb->get_var($wpdb->prepare("SELECT * FROM `{$wpdb->prefix}quads_stats`" ));
    if($stats>0){
        $wpdb->query( "UPDATE `{$wpdb->prefix}quads_stats` SET `End_of_post` = `End_of_post` + 1 " );
    }
}

add_action('wp_ajax_nopriv_quads_insert_ad_clicks_middle_of_post',  'quads_insert_ad_clicks_middle_of_post');      
add_action('wp_ajax_quads_insert_ad_clicks_middle_of_post',  'quads_insert_ad_clicks_middle_of_post');
function quads_insert_ad_clicks_middle_of_post( ){
    global $wpdb;
    $stats = $wpdb->get_var($wpdb->prepare("SELECT * FROM `{$wpdb->prefix}quads_stats`" ));
    if($stats>0){
        $wpdb->query( "UPDATE `{$wpdb->prefix}quads_stats` SET `Middle_of_post` = `Middle_of_post` + 1 " );
    }
}

add_action('wp_ajax_nopriv_quads_insert_ad_clicks_after_more_tag',  'quads_insert_ad_clicks_after_more_tag');      
add_action('wp_ajax_quads_insert_ad_clicks_after_more_tag',  'quads_insert_ad_clicks_after_more_tag');
function quads_insert_ad_clicks_after_more_tag( ){
    global $wpdb;
    $stats = $wpdb->get_var($wpdb->prepare("SELECT * FROM `{$wpdb->prefix}quads_stats`" ));
    if($stats>0){
        $wpdb->query( "UPDATE `{$wpdb->prefix}quads_stats` SET `After_more_tag` = `After_more_tag` + 1 WHERE `id` = {$stats};" );
    }
}


/**
 * Parse rotator default ads which can be enabled from general settings
 *
 * @global array $adsArray
 * @global int $visibleContentAds
 * @return string
 */
function quads_parse_rotator_ads($content)
{
    $off_default_ads = (strpos($content, '<!--OffDef-->') !== false);
    if ($off_default_ads) {
        return $content;
    }
    preg_match("#<!--CusRot(.+?)-->#si", $content, $match);
    if (!isset($match['1'])) {
        return $content;
    }
    $ad_id = $match['1'];
    if(!empty($ad_id)){
        $ad_meta = get_post_meta($ad_id, '',true);
    }
    $ads_list = !empty($ad_meta['ads_list']['0']) ? unserialize($ad_meta['ads_list']['0']) : "" ;

    if (!is_array($ads_list)) return $content;
    $temp_array =array();
    foreach ($ads_list as $ad ) {
        if (isset($ad['value'])){
            $temp_array[] = $ad['value'];
        }
    }

    $ad_code = array_rand($temp_array);

    $enabled_on_amp = (isset($ad_meta['enabled_on_amp'][0]))? $ad_meta['enabled_on_amp'][0]: '';

    $refresh_type                    =  isset($ad_meta['refresh_type'][0]) ? $ad_meta['refresh_type'][0] : '';
    $refresh_type_interval_sec       =  (isset($ad_meta['refresh_type_interval_sec'][0]) && !empty($ad_meta['refresh_type_interval_sec'][0])) ? $ad_meta['refresh_type_interval_sec'][0] : 0;

    $refresh_type_grid_column = isset( $ad_meta['grid_data_ad_column'][0] ) ? $ad_meta['grid_data_ad_column'][0] : 0 ;
    $refresh_type_grid_row = isset( $ad_meta['grid_data_ad_row'][0] ) ? $ad_meta['grid_data_ad_row'][0] : 0 ;
    // Number of Ads to Show
    $refresh_type_nofadstoshow = isset( $ad_meta['num_ads_t_s'][0] ) ? $ad_meta['num_ads_t_s'][0] : 0 ;

    $adsresultset = array();

    if($refresh_type == 'on_interval'){
        foreach ($temp_array as $post_ad_id){
            $ad_meta_group = get_post_meta($post_ad_id, '',true);
            if( get_post_status($post_ad_id) !== 'publish' ) {
                continue;
            }
            $adsresultset[] = array(
                'ad_id'                     => $post_ad_id,
                'ad_type'                   => $ad_meta_group['ad_type'],
                'ad_adsense_type'           => $ad_meta_group['adsense_type'],
                'ad_data_client_id'         => $ad_meta_group['g_data_ad_client'][0],
                'ad_data_ad_slot'           => $ad_meta_group['g_data_ad_slot'][0],
                // 'ad_custom_code'            => $ad_meta_group['custom_code'],
                'width'                     => $ad_meta_group['g_data_ad_width'],
                'height'                    => $ad_meta_group['g_data_ad_height'],
                'code'                      => $ad_meta_group['code'],
                'network_code'              => $ad_meta_group['network_code'],
                'ad_unit_name'              => $ad_meta_group['ad_unit_name'],
                // 'block_id'                  => $ad_meta_group['block_id'],
                'data_container'            => $ad_meta_group['data_container'],
                'data_js_src'               => $ad_meta_group['data_js_src'],
                'data_cid'                  => $ad_meta_group['data_cid'],
                'data_crid'                 => $ad_meta_group['data_crid'],
                'taboola_publisher_id'      => $ad_meta_group['taboola_publisher_id'],
                'mediavine_site_id'         => $ad_meta_group['mediavine_site_id'],
                'outbrain_widget_ids'       => $ad_meta_group['outbrain_widget_ids'],
                'image_redirect_url'        => $ad_meta_group['image_redirect_url'],
                'ad_image'                  => $ad_meta_group['image_src'],
            ) ;
        }
        $response['quads_group_id'] = $ad_id;
        $response['quads_refresh_type']           = 'on_interval';
        $response['quads_group_ref_interval_sec'] = $refresh_type_interval_sec;
        $response['quads_refresh_type_grid_column'] = $refresh_type_grid_column;
        $response['quads_refresh_type_grid_row'] = $refresh_type_grid_row;
        $response['quads_refresh_type_grid_num_of_ats'] = $refresh_type_nofadstoshow;
        $response['ads'] = $adsresultset;

        $arr = array(
            'float:none;text-align:center;',
            'float:none;margin:%1$dpx 0 %1$dpx 0;text-align:center;',
            'float:right;margin:%1$dpx 0 %1$dpx %1$dpx;',
            'float:none;margin:%1$dpx;');

        $adsalign = isset($quads_options['ads']['ad' . $ad_id]['align']) ? $quads_options['ads']['ad' . $ad_id]['align'] : ''; // default
        $adsmargin = isset( $quads_options['ads']['ad' . $ad_id]['margin'] ) ? $quads_options['ads']['ad' . $ad_id]['margin'] : ''; // default
        $margin = sprintf( $arr[( int ) $adsalign], $adsmargin );

        // Do not create any inline style on AMP site
        $style = !quads_is_amp_endpoint() ? apply_filters( 'quads_filter_margins', $margin, 'ad' . $ad_id ) : '';

        $code = "\n" . '<!-- WP QUADS v. ' . QUADS_VERSION . '  Rotator Ad -->' . "\n" .
            '<div class="quads-location quads-rotatorad ad_' . esc_attr($ad_id) . '" id="quads-rotate" style="' . $style . '">' . "\n";

        // $inserted_rotater_ads_data =  $response['ads'];
        // foreach ($inserted_rotater_ads_data as $key =>  $value) {
        //     $code .= '<span class="quads-location quads_click_impression ' . esc_attr($ad_id) . '" id="quads-ad'.esc_attr($value["ad_id"]).'" ></span>';
        // }
        $code .='<div class="quads-groups-ads-json" quads-group-id="'.esc_attr($ad_id).'" data-json="'. esc_attr(json_encode($response)).'">';
        $code .='</div>';
        $json_grid_column =  $response['quads_refresh_type_grid_column'] ;
        $json_grid_row =  $response['quads_refresh_type_grid_row'] ;

        $grid_row_css = '';
        if($json_grid_column>=1 && $json_grid_row == 1 ){
            $grid_row_css = 'style="grid-template-columns: auto"' ;
        }
        if($json_grid_column==1 && $json_grid_row==1 ){
            $grid_row_css = 'style="grid-template-columns: auto"' ;
        }
        if($json_grid_column==2 && $json_grid_row==2 ){
            $grid_row_css = 'style="grid-template-columns: auto auto"' ;
        }
        if($json_grid_column>=1 && $json_grid_row == 2 ){
            $grid_row_css = 'style="grid-template-columns: auto auto"' ;
        }
        if($json_grid_column>=1 && $json_grid_row == 3 ){
            $grid_row_css = 'style="grid-template-columns: auto auto auto"' ;
        }
        if($json_grid_column>=1 && $json_grid_row == 4 ){
            $grid_row_css = 'style="grid-template-columns: auto auto auto auto"' ;
        }

        $code .='<div style="display:none;" data-id="'.esc_attr($ad_id).'" class="quads_ad_container_pre"></div><div grid-area="'.esc_attr($json_grid_column.'*'.$json_grid_row).'" data-id="'.esc_attr($ad_id).'" class="quads quads_ad_container" '.$grid_row_css.' ></div>';

        $code .= '</div>' . "\n";

        $cont = explode('<!--CusRot'.$ad_id.'-->', $content, 2);

        $content =  $cont[0].$code.$cont[1];
        $js_dir = QUADS_PRO_PLUGIN_URL . 'assets/js/';

        // Use minified libraries if SCRIPT_DEBUG is turned off
        $suffix = ( quadsIsDebugMode() ) ? '' : '.min';

        // These have to be global
        wp_enqueue_script( 'quads-rotator_ads', $js_dir . 'rotator_ads' . $suffix . '.js', array('jquery'), QUADS_PRO_VERSION, false );

    }else{
        $content = quads_replace_ads_new( $content, 'CusRot' . $ad_id, $temp_array[$ad_code],$enabled_on_amp);
    }
    return  $content ;
}

/**
 * Parse rotator default ads which can be enabled from general settings
 *
 * @global array $adsArray
 * @global int $visibleContentAds
 * @return string
 */
function quads_parse_group_insert_ads($content) {

    $off_default_ads = (strpos( $content, '<!--OffDef-->' ) !== false);
    if( $off_default_ads ) {
        return $content;
    }
    preg_match("#<!--CusGI(.+?)-->#si", $content, $match);
    if(!isset($match['1'])){
        return $content;
    }
    $ad_id = $match['1'];
    if(!empty($ad_id)){
        $ad_meta = get_post_meta($ad_id, '',true);
    }
    $ads_list = unserialize($ad_meta['ads_list']['0']);

    if (!is_array($ads_list)) return $content;
    $temp_array =array();
    foreach ($ads_list as $ad ) {
        if (isset($ad['value'])){
            $temp_array[] = $ad['value'];
        }
    }
    $temp_array_count        =count($temp_array);
    for($j=0; $j < $temp_array_count;$j++){
        $enabled_on_amp = (isset($ad_meta['enabled_on_amp'][0]))? $ad_meta['enabled_on_amp'][0]: '';
        $content = quads_replace_ads_new( $content, 'CusGI' . $ad_id, $temp_array[$j],$enabled_on_amp);
        if($j == $temp_array_count-1){
            $number_rand_ads = substr_count( $content, '<!--CusGI' );
            if($number_rand_ads > 0){
                $j = -1;
            }
        }
    }
    return $content;
}

/**
 * Parse Sticky Scroll default ads which can be enabled from general settings
 *
 * @global array $adsArray
 * @global int $visibleContentAds
 * @return string
 */
function quads_parse_sticky_scroll_ads($content) {

    $off_default_ads = (strpos( $content, '<!--OffDef-->' ) !== false);
    if( $off_default_ads ) {
        return $content;
    }
    preg_match("#<!--CusSS(.+?)-->#si", $content, $match);
    if(!isset($match['1'])){
        return $content;
    }
    $ad_id = $match['1'];

    if(!empty($ad_id)){
        $ad_meta = get_post_meta($ad_id, '',true);
    }
    $useragent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '' ;
    if(isset($ad_meta) && !quads_is_amp_endpoint() && preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))
    {
        $temp_con='<div class="wpquads-sticky-container"><div class="wpquads-sticky-row"><div class="wpquads-sticky-ads"><!--CusSS'.$ad_id.'--></div></div></div>';
        $temp_con.='</div><style>.wpquads-sticky-row{display:flex;justify-content:space-around;align-items:flex-start;height:'.$ad_meta['sticky_scroll_height'][0].'px}.wpquads-sticky-container{border:1px dashed rgba(114,186,94,.35)}.wpquads-sticky-ads{position:sticky;top:0;padding:20px 0;overflow:hidden;}.wpquads-sticky-continue{padding:5px;margin:0 auto;width:100%;text-align:center}.wpquads-sticky-row img{max-width:100%;}</style>';
        $content = preg_replace('/<!--CusSS.*-->/i', $temp_con, $content);
    }
   
    $ads_list = unserialize($ad_meta['ads_list']['0']);

    if (!is_array($ads_list)) return $content;
    $temp_array =array();
    foreach ($ads_list as $ad ) {
        if (isset($ad['value'])){
            $temp_array[] = $ad['value'];
        }
    }
    $temp_array_count        =count($temp_array);
    for($j=0; $j < $temp_array_count;$j++){
        $enabled_on_amp = (isset($ad_meta['enabled_on_amp'][0]))? $ad_meta['enabled_on_amp'][0]: '';
        $content = quads_replace_ads_new( $content, 'CusSS' . $ad_id, $temp_array[$j],$enabled_on_amp);
       
        if($j == $temp_array_count-1){
            $number_rand_ads = substr_count( $content, '<!--CusSS' );
            if($number_rand_ads > 0){
                $j = -1;
            }
        }
    }
  
    return $content;
}

/**
 * Return the ad label
 * 
 * @return string
 */
function quads_render_ad_label( $adcode ) {
   global $quads_options,$quads_mode;
    if($quads_mode !='new'){
       $position = isset( $quads_options['adlabel'] ) && $quads_options['adlabel'] !== 'none' ? $quads_options['adlabel'] : 'none';

       $label = apply_filters( 'quads_ad_label', 'Advertisements' );

       $html = '<div class="quads-ad-label">' . sanitize_text_field($label) . '</div>';

       if( $position === 'none' ) {
          return $adcode;
       }
       if( $position === 'above' ) {
          return $html . $adcode;
       }
       if( $position === 'below' ) {
          return $adcode . $html;
       }
    }else{
      return $adcode;
    }
}

add_filter( 'quads_render_ad', 'quads_render_ad_label' );

/**
 * Overwrite custom advert code.
 * Can be used in functions.php to overwrite ads
 * 
 * @param string $id number of the ad
 * @return string ad code
 */
function quads_overwrite_ad( $id ) {
   // Overwrite an ad with custom one
   $custom_ad = apply_filters( 'quads_overwrite_ad', $id );

   if( isset( $custom_ad[$id] ) ) {
      return $custom_ad[$id];
   }

   if( !empty( $custom_ad ) && !is_array( $custom_ad ) ) {
      return $custom_ad;
   }

   return false;
}

/**
 * Add more margin positions
 * 
 * @global array $quads_options
 * @param string $margin
 * @param int $id
 * @return string
 */
function quads_pro_add_margin( $style, $id ) {
   global $quads_options;

   if( empty( $quads_options['ads'][$id]['margin-left'] ) &&
           empty( $quads_options['ads'][$id]['margin-top'] ) &&
           empty( $quads_options['ads'][$id]['margin-right'] ) &&
           empty( $quads_options['ads'][$id]['margin-bottom'] ) ) {
      return $style;
   }

   $top = isset( $quads_options['ads'][$id]['margin-top'] ) ? $quads_options['ads'][$id]['margin-top'] : '0';
   $right = isset( $quads_options['ads'][$id]['margin-right'] ) ? $quads_options['ads'][$id]['margin-right'] : '0';
   $bottom = isset( $quads_options['ads'][$id]['margin-bottom'] ) ? $quads_options['ads'][$id]['margin-bottom'] : '0';
   $left = isset( $quads_options['ads'][$id]['margin-left'] ) ? $quads_options['ads'][$id]['margin-left'] : '0';

   $arr = array(
       'float:left;margin:%1$dpx %2$dpx %3$dpx %4$dpx;',
       'float:none;margin:%1$dpx %2$dpx %3$dpx %4$dpx;text-align:center;',
       'float:right;margin:%1$dpx %2$dpx %3$dpx %4$dpx;',
       'float:none;margin:%1$dpx %2$dpx %3$dpx %4$dpx;');

   $align = isset( $quads_options['ads'][$id]['align'] ) ? $quads_options['ads'][$id]['align'] : '3'; // 3 is default
   $style = sprintf( $arr[( int ) $align], $top, $right, $bottom, $left );

   return $style;
}

add_filter( 'quads_filter_margins', 'quads_pro_add_margin', 2, 3 );

/**
 * Add more margin positions for widgets
 * 
 * @global array $quads_options
 * @param string $margin
 * @param int $id
 * @return string
 */
function quads_pro_add_widget_margin( $style, $id ) {
   global $quads_options;

   if( empty( $quads_options['ads'][$id]['margin-left'] ) &&
           empty( $quads_options['ads'][$id]['margin-top'] ) &&
           empty( $quads_options['ads'][$id]['margin-right'] ) &&
           empty( $quads_options['ads'][$id]['margin-bottom'] ) ) {
      return $style;
   }

   $top = isset( $quads_options['ads'][$id]['margin-top'] ) ? $quads_options['ads'][$id]['margin-top'] : '0';
   $right = isset( $quads_options['ads'][$id]['margin-right'] ) ? $quads_options['ads'][$id]['margin-right'] : '0';
   $bottom = isset( $quads_options['ads'][$id]['margin-bottom'] ) ? $quads_options['ads'][$id]['margin-bottom'] : '0';
   $left = isset( $quads_options['ads'][$id]['margin-left'] ) ? $quads_options['ads'][$id]['margin-left'] : '0';

   $arr = array(
       'float:left;margin:%1$dpx %2$dpx %3$dpx %4$dpx;',
       'float:none;margin:%1$dpx %2$dpx %3$dpx %4$dpx;text-align:center;',
       'float:right;margin:%1$dpx %2$dpx %3$dpx %4$dpx;',
       'float:none;margin:%1$dpx %2$dpx %3$dpx %4$dpx;');

   $align = isset( $quads_options['ads'][$id]['align'] ) ? $quads_options['ads'][$id]['align'] : '3'; // 3 is default
   $style = sprintf( $arr[( int ) $align], $top, $right, $bottom, $left );

   return $style;
}

add_filter( 'quads_filter_widget_margins', 'quads_pro_add_widget_margin', 2, 3 );

/**
 * Flattens an array
 * 
 * @param array $array
 * @return array
 */
function quads_flatten( array $array ) {
   $new = array();
   foreach ( $array as $value ) {
      $new += $value;
   }
   return $new;
}


/**
 * Check extra stuff
 * 
 * @return boolean
 */
function quads_extra() {
   return true;
}

add_filter( 'quads_localize_filter', 'quads_is_pro_activated',10,2);
function quads_is_pro_activated($object, $object_name){	
	$object['is_pro'] = true;	
	return $object;
}

  function quads_hide_markup(){ 
     global $quads_options;
     $quads_license_key = isset( $quads_options['quads_wp_quads_pro_license_key'] ) ? $quads_options['quads_wp_quads_pro_license_key'] : '';
      if(!empty($quads_license_key)){

                if(isset( $quads_options['hide_quads_markup'] ) && $quads_options['hide_quads_markup']){

                  return true;
                }
            }
            return false;
  }


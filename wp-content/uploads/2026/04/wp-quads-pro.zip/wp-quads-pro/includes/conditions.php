<?php

/**
 * Condition Functions
 *
 * @package     QUADS
 * @subpackage  Functions/Conditions
 * @copyright   Copyright (c) 2016, René Hermenau
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.3.1
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) )
   exit;



/**
 * Check if ad is allowed on extra conditions like post tags
 *
 * @global array $quads_options
 * @global array $post
 * @return boolean true if tag is allowed
 */
function quads_hide_on_tags($isActive) {
   global $quads_options, $post,$quads_mode;
   // exit early. This condition can only be valid on post tags
   if( !isset( $post ) ) {
      return false;
   }
	$global_exclude= [];
	if( $quads_mode == 'new' && (isset( $quads_options['multiTagsValue'])) ) {
	   $global_exclude = array_column($quads_options['multiTagsValue'], 'value');
   }else if($quads_mode !='new' && (isset( $quads_options['tags'])) ) {
	   $global_exclude = $quads_options['tags'];
   }
	if(empty($global_exclude)){
		return $isActive;
	}

   // Create array of slugs containing tag names
   $tagsObj = wp_get_post_tags( $post->ID );
   $tags = array();

   foreach ( $tagsObj as $key => $value ) {
      $tags[$key] = trim( $value->slug );
   }
   if(  isset( $tags ) && count( array_intersect( $global_exclude, $tags ) ) >= 1 ) {
      return true;
   }
   return $isActive;
}

add_filter( 'quads_hide_ads', 'quads_hide_on_tags', 5 );

/**
 * Hide ads per post id
 *
 * @global array $quads_options
 * @global array $post
 * @return boolean
 */
function quads_hide_on_post_id($isActive){
    global $quads_options, $post;

   // exit early. This condition can only be valid on post ids
    if (!isset($post) || empty($quads_options['excluded_id'])) {
        return $isActive;
    }

    $excluded = !empty($quads_options['excluded_id']) ? $quads_options['excluded_id'] : null;

    if (strpos($excluded, ',') !== false) {
        $excluded = explode(',', $excluded);
        if (in_array($post->ID, $excluded)) {
            return true;
        }
    }
    if ($post->ID == $excluded) {
        return true;
    }

    // default condition
    return $isActive;
}

add_filter('quads_hide_ads', 'quads_hide_on_post_id', 6);

function quads_user_roles_permission_new($isActive){
	global $quads_options;
	// No restriction. Show ads to all user_roles including public visitors without user role
	if (!isset($quads_options['multiUserValue'])){
		return $isActive;
	}
	$roles = wp_get_current_user()->roles;
	foreach ($quads_options['multiUserValue'] as $role){
		if(isset($role['value']) && isset($roles[0]) && $role['value'] == $roles[0]){
			return false;
		}
	}
	return $isActive;
}
global $quads_mode;
if($quads_mode == 'new') {
	add_filter( 'quads_hide_ads', 'quads_user_roles_permission_new', 5 );
}

/**
 * Hide ads on buddypess pages
 *
 * @global array $quads_options
 * @global array $post
 * @return boolean
 */
function quads_hide_buddypress($isActive){

	global $quads_options,$quads_mode;
	// exit early. This condition can only be valid if buddypress plugin is installed
	if (!function_exists('is_buddypress')) {
		return $isActive;
	}
	$global_exclude= [];
	if( $quads_mode == 'new' && (isset( $quads_options['multiPluginsValue'])) ) {
		$global_exclude = array_column($quads_options['multiPluginsValue'], 'value');
	}else if($quads_mode !='new' && (isset( $quads_options['plugins'])) ) {
		$global_exclude = $quads_options['plugins'];
	}
	if(empty($global_exclude)){
		return $isActive;
	}

	if ( is_array($global_exclude) && in_array('buddypress', $global_exclude) && is_buddypress() ){
		return true;
	}
	// default condition
	return $isActive;

}

add_filter('quads_hide_ads', 'quads_hide_buddypress', 7);
/**
 * Hide ads on woocommerce pages
 *
 * @global array $quads_options
 * @global array $post
 * @return boolean
 */
function quads_hide_woocommerce($isActive){
	global $quads_options,$quads_mode;
	// exit early. This condition can only be valid if buddypress plugin is installed
	if (!function_exists('is_woocommerce')) {
		return $isActive;
	}
	$global_exclude= [];
	if( $quads_mode == 'new' && (isset( $quads_options['multiPluginsValue'])) ) {
		$global_exclude = array_column($quads_options['multiPluginsValue'], 'value');
	}else if($quads_mode !='new' && (isset( $quads_options['plugins'])) ) {
		$global_exclude = $quads_options['plugins'];
	}
	if(empty($global_exclude)){
		return $isActive;
	}

	if ( is_array($global_exclude) && in_array('woocommerce', $global_exclude) && is_woocommerce() ){
		return true;
	}
	// default condition
	return $isActive;
}

add_filter('quads_hide_ads', 'quads_hide_woocommerce', 8);



/**
 * Check if display conditions should be running for shortcode generated ads like [quads]
 * Must be last filter
 */

//function quads_hide_on_shortcodes($isActive){
//    global $quads_options;
//
//    if (isset($quads_options['ignoreShortcodeCond'])){
//        return false;
//    }
//    // default filtered condition
//    return $isActive;
//}
//add_filter('quads_hide_ads', 'quads_hide_on_shortcodes', 9);

/**
 * Overwrite post_type display conditions for shortcode generated ads like [quads]
 */

//function quads_is_post_type_allowed($isActive){
//    global $quads_options;
//
//    if (isset($quads_options['ignoreShortcodeCond'])){
//        return true;
//    }
//    // default post_type filtered condition
//    return $isActive;
//}
//add_filter('quads_post_type_allowed', 'quads_is_post_type_allowed', 1);


/**
 *
 * @param type $arrActivatedAds
 * @return array List of ad id's
 */
function quads_filter_ads( $args ) {
   global $quads_options;

   // Get all the paragraph values[]
   $paragraph = $args['paragraph'];

   //Add some extra paragraph positions
   $number = 11; // number of paragraph ads to loop
   for ( $i = 4; $i <= $number; $i++ ) {

      $key = ($i - 4) + 1; // 1,2,3

      $paragraph['status'][$i] = isset( $quads_options['extra' . $key]['ParAds'] ) ? $quads_options['extra' . $key]['ParAds'] : 0; // Status - active | inactive
      $paragraph['id'][$i] = isset( $quads_options['extra' . $key]['ParRnd'] ) ? $quads_options['extra' . $key]['ParRnd'] : 0; // Ad id
      $paragraph['position'][$i] = isset( $quads_options['extra' . $key]['ParNup'] ) ? $quads_options['extra' . $key]['ParNup'] : 0; // Paragraph No
      $paragraph['end_post'][$i] = isset( $quads_options['extra' . $key]['ParCon'] ) ? $quads_options['extra' . $key]['ParCon'] : 0; // End of post - yes | no
   }


   for ( $i = 1; $i <= $number; $i++ ) {
      if( $paragraph['id'][$i] == 0 ) {
         $paragraph[$i] = $args['cusrnd'];
      } else {
         $paragraph[$i] = $args['cusads'] . $paragraph['id'][$i];
         array_push( $args['AdsIdCus'], $paragraph['id'][$i] );
      };
   }
   // Convert all return values into one array()
   $args = array('paragraph' => $paragraph,
       'AdsIdCus' => $args['AdsIdCus']
   );

   return $args;
}

add_filter( 'quads_filter_paragraphs', 'quads_filter_ads' );



function quadspro_visitor_comparison_logic_checker($result,$visibility ){
    $v_type       = $visibility['type']['value'];
    $v_id         = $visibility['value']['value'];

    switch ($v_type) {

        case 'geo_location_country':

           $quads_client_info = array();
           $quads_client_info = quads_get_ip_geolocation();

            if (isset($quads_client_info['countryCode']) && $quads_client_info['countryCode'] != $v_id ) {
              $result = false;
            }else{
              $result = true;
            }
        break;
        case 'geo_location_city':

           $quads_client_info = array();
           $quads_client_info = quads_get_ip_geolocation();
           if(isset($quads_client_info['city'])){
              $city_cookie = str_replace(' ','',$quads_client_info['city']);
              $city_cookie = strtolower($city_cookie);
              $city        = str_replace(' ','',$v_id);
              $city        = strtolower($city);
              if($city_cookie !=  $city) {
                $result = false;
              }else{
              $result = true;
            }
            }
        break;
      }
      return $result;
}

add_filter( 'quads_visitor_comparison_logic_checker', 'quadspro_visitor_comparison_logic_checker',10 ,2 );
if (!function_exists('quads_get_client_ip')) {
   function quads_get_client_ip() {

       if (isset($_SERVER['HTTP_CF_CONNECTING_IP']))  //for cloudflare server only
           $ipaddress = $_SERVER['HTTP_CF_CONNECTING_IP'];
       else if (isset($_SERVER['HTTP_CLIENT_IP']))
          $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
      else if(isset($_SERVER['REMOTE_ADDR']))
          $ipaddress = $_SERVER['REMOTE_ADDR'];
      else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
          $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
      else if(isset($_SERVER['HTTP_X_FORWARDED']))
          $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
      else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
          $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
      else if(isset($_SERVER['HTTP_FORWARDED']))
          $ipaddress = $_SERVER['HTTP_FORWARDED'];
      else
          $ipaddress = 'UNKNOWN';
      return $ipaddress;
  }
}
  if (!function_exists('quads_get_ip_geolocation')) {
    function quads_get_ip_geolocation(){
      if(!is_admin()){
        global $quads_options;
        $user_ip      = quads_get_client_ip();
        $saved_ip = '';
        $saved_ip_list = array();
        $quads_client_info = array();
        if(isset($_COOKIE['quads_client_info'])){
          $saved_ip_list = json_decode(base64_decode($_COOKIE['quads_client_info']),true);
          $saved_ip = trim($saved_ip_list['ipaddress']);
          $quads_client_info['ipaddress']=$saved_ip;
          $quads_client_info['countryCode']=trim($saved_ip_list['countryCode']);
          $quads_client_info['region']=trim($saved_ip_list['region']);
          $quads_client_info['city']=trim($saved_ip_list['city']);
        }
        else if(isset($_SESSION['quads_client_info_arr']))
        {
          $saved_ip_list = $_SESSION['quads_client_info_arr'];
          $saved_ip = trim($saved_ip_list['ipaddress']);
          $quads_client_info['ipaddress']=$saved_ip;
          $quads_client_info['countryCode']=trim($saved_ip_list['countryCode']);
          $quads_client_info['region']=trim($saved_ip_list['region']);
          $quads_client_info['city']=trim($saved_ip_list['city']);	
        }
        if($saved_ip != $user_ip){
          $quads_license_key = isset( $quads_options['quads_wp_quads_pro_license_key'] ) ? $quads_options['quads_wp_quads_pro_license_key'] : '';
          if(empty($quads_license_key)){
              return '';
          }
           
          $geo_location_data = wp_remote_get('https://us-central1-golden-academy-286513.cloudfunctions.net/function-1?ipaddress='.$user_ip,array(
          'headers' => array( 'quads_auth' => $quads_license_key)
            ));
	
            if(!is_wp_error($geo_location_data)){
              if(is_array($geo_location_data) && !empty($geo_location_data['body']) ){
                $geo_location_arr  = unserialize($geo_location_data['body']);
                if(isset($geo_location_arr['status']) && $geo_location_arr['status'] == 'success'){
                  $quads_client_info = array();
                  $quads_client_info['ipaddress'] = (isset($geo_location_arr['query']))?$geo_location_arr['query'] : "";
                  $quads_client_info['countryCode'] = (isset($geo_location_arr['countryCode']))?$geo_location_arr['countryCode'] : "";
                  $quads_client_info['region'] = (isset($geo_location_arr['region']))?$geo_location_arr['region'] : "";
                  $quads_client_info['city'] = (isset($geo_location_arr['city']))?$geo_location_arr['city'] : "";
                  $quads_client_info_json = json_encode($quads_client_info);
                  $_SESSION['quads_client_info']=trim(base64_encode($quads_client_info_json));
                  $_SESSION['quads_client_info_arr']=$quads_client_info;
                }
              }              
            }        
        }
          return $quads_client_info;
      }
    }
}

add_action('wp_head', 'quads_set_client_info_script');
function quads_set_client_info_script(){
  if(isset($_SESSION['quads_client_info']) && !empty($_SESSION['quads_client_info']) && !is_admin() && !quads_is_amp_endpoint()){
    echo "<script type='text/javascript'>document.cookie = 'quads_client_info=".esc_attr($_SESSION['quads_client_info']).";max-age=86400 * 60';</script>";
  }
}
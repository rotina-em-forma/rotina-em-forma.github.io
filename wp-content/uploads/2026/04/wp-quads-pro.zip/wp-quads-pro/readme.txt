=== AdSense Integration WP QUADS PRO === 

Author URL: https://wpquads.com
Plugin URL: https://wordpress.org/plugins/quick-adsense-reloaded/
Contributors: wpquads
Donate link: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: advertising, ads, adsense, google, google adsense, posts, post, page, sidebar, shortcode, admin, plugin, widget
Requires at least: 3.6+
Tested up to: 6.1
Stable tag: 2.0.19

WP QUADS PRO The quickest way to insert Google AdSense & other ads into your website. Google AdSense integration simplified!

== Description == 

#### WPQUADS PRO

This is an add-on for the free plugin WP QUADS PRO


= Main Features =

* Import all ads settings from Quick AdSense v. 1.9.2 and convert them into serialized options.
* No revenue sharing from your Google AdSense advertising income.
* Quicktags of Quick Adsense are 100% compatible to Quick AdSense Reloaded
* No external script dependencies. All plugin code reside on your site. 
* Dynamic AdSense positioning: Assign Google AdSense ads to the beginning, middle and end of post, assign dds after 'more' tag, before last paragraph, after certain paragraphs & assign Ads after certain images.
* Insert Google AdSense ads specifically or randomly anywhere within a post.
* Support any Ads code, not limited to Google Adsense dds only.
* Display up to a maximum of 10 Ads on a page. Google TOS allows publishers to place up to 3 Google Adsense for Content on a page. If you are using other dds, you may display up to 10 Ads.
* Support up to a maximum of 10 Ads codes on Sidebar Widgets.
* Support up to a maximum of 10 Ads codes for specific placement & randomization within a post.
* Insert Google AdSense ads on-the-fly, insert &lt;!--Ads1--&gt;, &lt;!--Ads2--&gt; ... , &lt;!--RndAds--&gt; to a post to accomplish this.
* Disable Ads on-the-fly, insert &lt;!--NoAds--&gt;, &lt;!--OffDef--&gt;, &lt;!--OffWidget--&gt;, &lt;!--OffBegin--&gt; ... and more to a post to accomplish this.
* The above quicktags can be inserted into a post easily via the additional Quicktag Buttons added to the HTML Edit Post SubPanel.

= Improvements to original Quick AdSense Ads plugin =

* Performance improvements
* Serialized storing of Ad options instead storing every single option as separate table entry all over
* Multi language support
* Remove of small coding issues like "unexpected output" message when plugin is activated on several sites
* Import / Export function makes plugin migrating to other sites easier. Copy your dds code to other sites.

= Safety improvements = 

* Exit code if Quick AdSense plugin is not called by WordPress directly 
* Better sanitizing of user input


= High Performance =

Quick AdSense Reloaded is *coded well and developed for high performance*.
It loads only the code it needs at the moment of execution, making it small and fast and with a lot of hooks easy extensible by third party developers.


== Frequently Asked Questions ==

Post your question in the [support forum](http://wpquads.com/your-account/)

== Installation ==

1. Download the plugin. 
2. Upload it via Plugins->Add New->Uploads.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog == 

= 2.0.19 ( 31 March 2023 ) =
* Fix: Deprecated: str_replace(): Passing null to parameter #2 ($replace) of type array|string is deprecated in php 8.2 #712

= 2.0.18 ( 16 January 2023 ) =
* Fix: Fatal error on Ab testing ad (Pro) #682

= 2.0.17 ( 09 January 2023 ) =
* Fix: Background ad is not working as per Geo location #692
* Fix: The Ad targeting option "Country" is not working properly #691

= 2.0.16 ( 31 December 2022 ) =
* Fix: Fatal error and geolocation not working #686 
* Fix: 502 error on site without SSL

= 2.0.15 ( 17 August 2022 ) =
* Added: Hold & Scroll - View onScroll Ad. #586

= 2.0.14 ( 12 July 2022 ) =
* Fix: rendering rotator ads center position. #575
* Fix: console error when performance option is disabled. #583

= 2.0.13 (18 April 2022) =
* Fix: Impressions & clicks not counting properly. #515

= 2.0.12 (09 April 2022) =
* Fix: impressions and clicks not added using rotator ads. #493

= 2.0.11 (17 March 2022) =
* Fix: Drafted & Deleted ads rendering in rotator ads #487

= 2.0.10 (01 March 2022) =
* Fix: more than 1 Ad in rotator ads are not working/overlapping #473
* Fix: rotator ads taking last updated ads and not respective ads #474

= 2.0.9 (31 January 2022) =
* Fix: Added Live AD Rotation in one group as a Grid Feature #461

= 2.0.8 (26 July 2021) =
* Fix: Added Filter for ad_blindness Feature #23

= 2.0.7 (21st April 2021) =
* Fix: FIxed conflict with Soliloquy #21

= 2.0.6 (3rd April 2021) =
* Fix: Geolocation targeting feature is not working cloudflare server. #337

= 2.0.5 (16th March 2021) =
* New: Adsense Reports #290
* Fix: Hide ads for user roles #313

= 2.0.4 (09th March 2021) =
* New: created an option to remove Quads Markup #180
* Fix: separate the "Serbia and Montenegro" in the country list for targeting #323

= 2.0.3 (21th January 2021) =
* New: New Group Insertion #297

= 2.0.2 (05th January 2021) =
* New: Ads rotator feature #274

= 2.0.1 (27th August 2020) =
* New: Geo Location improvements #156

= 2.0 =
* New interface added
* New : Added ad label for the new interface #117.

= 1.4.6 =
* New: Compatible to WordPress 5.3.3

= 1.4.5 =
* New: Compatible to WordPress 5.3.0
* New: Increase loading performance of the plugin and lower loading time for the website

= 1.4.4 =
* New: Compatible to WordPress 5.2.3

= 1.4.3 =
* New: Supports WP 5.2.1
* Tweak: Better wordings
* New: Allow shortcodes in amp input ad form

= 1.4.2 =
* New: Support for Google Auto ads
* New: Add 6 more paragraph ads. So you can use a total of 11 paragraph ads from now on.
* Fix: Google Analytics Ad Blocker event fired for every page request resulting in wrong number of ad blocker users
* Tweak: Better disable ad blocker notice
* Tweak: Does not work with php 5.2 and older

= 1.4.1 =
* New: Option to show shortcode generated ads even though automatic ads are disabled
* Fix: WP QUADS Pro not working if valid license has been expired

= 1.4.0 =
* Fix: Buddypress condition not working if woocommerce is enabled as well.
* Fix: Select tags by search term to prevent timeout and memory issue on sites with hundreds of tags
* Fix: Margin and alignment option not working for widget ads

= 1.3.9 =
* Tweak: Clean up settings
* Tweak: Make more clear where to ask for support
* Fix: Single margin option shown if wp quads pro is installed but not activated

= 1.3.8 =
* New: Condition to exclude certain post id's
* New: Condition to exclude ads on woocommerce pages
* New: Condition to exclude ads on buddypress pages
* Fix: Margin option not working properly after updating wp quads to 1.5.5 and higher

= 1.3.7 =
* Fix: Responsive Sizes are ignored after latest update

= 1.3.6 =
* New: Support for unlimited amount of ads
* New: Compatible up to WordPress 4.8
* Fix: Security Update. Updating is highly recommended

= 1.3.5 =
* New: Add new option to hide AMP ads on certain posts with WP QUADS PRO
* Fix: Google Analytics event tracking for ad blocker not working
* Fix: Ad Blocker notice blocked by ad blocker

= 1.3.4 =
* Fix: Google Analytics ad blocks are not counted any time
* Fix: Ad blocker notice not shown if analytics option is disabled

= 1.3.3 =
* New: Add 3 more paragraph options
* New: Google Analytics Tracking if user is using ad blocker or not
* New: Show message asking user to deactivate their ad blocker
* Tweak: Performance update. Uses less resources


= 1.3.2 =
* Fix: post tags condition not working with some slugs

= 1.3.1 =
* New: Support for tag visibility condition with WP QUADS 1.3.1

= 1.3.0 =
* New: Show/Hide ads on custom post types with WP QUADS PRO
* New: Hide adverts for specific custom user role with WP QUADS PRO

= 1.2.9 =
* New: Allow use of other amp vendor codes with use of wp quads pro

= 1.2.8 =
* Fix: AdSense label must be "Advertisements" plural form instead "Advertisment" as stated in the Google AdSense TOS
* New: Support for all post_types including custom ones

= 1.2.7 =
* Tweak: Change ad label Advertisements to Advertisement
* Fix: Make plugin package update proof and include subfolder with plugin name into zip
* Fix: Undefined index notice
* New: Support for multiple margin values: top, right, bottom, left (Needs WP QUADS PRO)


= 1.2.6 =
* Fix: WP QUADS PRO can not be detected if folder name is not default wp-content/plugins/wp-quads-pro

= 1.2.5 =
* New: AMP Support

= 1.2.4 =
* Tweak: Minnor changes 

= 1.2.3 =
* New: Add Custom Banner Sizes
* New: Add AdSense label
* Tweak: Change description of the ad size setting
* Tweak: Better description that PRO version must be installed together with free version

= 1.2.2 =
* Create a add-on instead standalone. WP QUADS is needed to run this plugin

= 1.2.1 =
* Fix: Fatal Error on frontpage

= 1.2.0 =
* New: Create pro version with mobile support
* New: Pro Version with responsive adsense support

INITIAL VERSION


== Upgrade Notice ==

= 1.3.8 =
1.3.8 New Features
